let currentUser = "";
let activeReqId = "";
let currentShareUrl = "";

window.onload = () => {
    lucide.createIcons();
    if(window.location.hash.includes('requestee/')) {
        activeReqId = window.location.hash.split('/')[1];
        showRequestee();
    }
};

async function handleAuth(type) {
    const user = document.getElementById('username-input').value;
    if(!user) return;
    const res = await fetch('/api/' + type, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ username: user })
    });
    const data = await res.json();
    if(res.ok) { currentUser = data.username; showMain(); }
    else { Swal.fire('Eroare', data.error, 'error'); }
}

async function showMain() {
    hideAll();
    document.getElementById('main-view').classList.remove('hidden');
    document.getElementById('user-display').innerText = "@" + currentUser;
    
    const uRes = await fetch('/api/user/' + currentUser);
    const uData = await uRes.json();
    
    const balance = parseFloat(uData.balance) || 0;
    document.getElementById('total-balance').innerText = balance.toFixed(2);

    const rRes = await fetch('/api/my-requests/' + currentUser);
    const rData = await rRes.json();
    document.getElementById('my-requests').innerHTML = rData.map(r => {
        const collected = parseFloat(r.total_collected) || 0;
        const requested = parseFloat(r.amount) || 0;
        return `
            <div class="history-item">
                <div><b>${r.reason}</b><br><small>${requested.toFixed(2)} RON ceruti</small></div>
                <div style="color:#22c55e; font-weight:900">+${collected.toFixed(2)}</div>
            </div>
        `;
    }).join('') || '<p class="text-center text-muted">Gol.</p>';
    lucide.createIcons();
}

async function topUp() {
    const { value: amount } = await Swal.fire({
        title: 'Alimentare',
        input: 'number',
        confirmButtonText: 'Adaugă'
    });
    console.log('topUp called, amount:', amount, 'currentUser:', currentUser);
    if (amount) {
        console.log('Sending add-funds request with amount:', parseFloat(amount));
        const res = await fetch('/api/add-funds', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ username: currentUser, amount: parseFloat(amount) })
        });
        console.log('add-funds response status:', res.status, 'ok:', res.ok);
        if (res.ok) {
            console.log('Funds added successfully');
            showMain();
        } else {
            const errorData = await res.json();
            console.error('Error adding funds:', errorData);
            Swal.fire('Eroare', errorData.error || 'Eroare necunoscută', 'error');
        }
    } else {
        console.log('No amount entered');
    }
}

async function generateQR() {
    const res = await fetch('/api/requests', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ 
            amount: document.getElementById('req-amount').value, 
            reason: document.getElementById('req-reason').value, 
            createdBy: currentUser 
        })
    });
    const data = await res.json();
    currentShareUrl = window.location.origin + "/#requestee/" + data.id;
    document.getElementById('qr-result').src = data.qrCodeData;
    hideAll();
    document.getElementById('qr-view').classList.remove('hidden');
}

function shareLink() {
    navigator.clipboard.writeText(currentShareUrl);
    Swal.fire('Copiat!', 'Link-ul este în clipboard.', 'success');
}

async function showRequestee() {
    if(!currentUser) {
        const { value: name } = await Swal.fire({ title: 'Cine ești?', input: 'text', allowOutsideClick: false });
        currentUser = name || "Anonim";
    }
    const res = await fetch('/api/requests/' + activeReqId);
    const data = await res.json();
    
    const amount = parseFloat(data.amount) || 0;
    
    document.getElementById('sender-initial').innerText = data.created_by[0].toUpperCase();
    document.getElementById('pay-msg').innerText = data.created_by + " îți cere bani";
    document.getElementById('pay-amount').innerText = amount.toFixed(2) + " RON";
    hideAll();
    document.getElementById('requestee-view').classList.remove('hidden');
    lucide.createIcons();
}

async function respond(status) {
    const res = await fetch('/api/requests/' + activeReqId + '/respond', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ username: currentUser, status })
    });
    const data = await res.json();
    if(!res.ok) return Swal.fire('Eroare', data.error, 'error');
    
    await Swal.fire('Gata', status === 'accepted' ? 'Plătit!' : 'Refuzat', 'success');
    window.location.hash = "";
    showMain();
}

function hideAll() { document.querySelectorAll('.view, .card').forEach(el => el.classList.add('hidden')); document.getElementById('app').classList.remove('hidden'); }
function showCreate() { hideAll(); document.getElementById('create-view').classList.remove('hidden'); }